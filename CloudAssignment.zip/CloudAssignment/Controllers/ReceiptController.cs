﻿using System;
using System.Collections.Generic;
using System.Linq;

using System.Web;
using System.Web.Mvc;
using CloudAssignment.Models;


namespace CloudAssignment.Controllers
{
    public class ReceiptController : Controller
    {
        // GET: Receipt
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult AddReceipt()
        {
            return View();
        }
        [HttpPost]
        public ActionResult AddReceipt(FormCollection fc)
        {
            Receipt receipt = new Receipt();

            receipt.ReceiptNumber = Convert.ToInt32(fc["ReceiptNumber"]);
            receipt.ReceiptDate = DateTime.Parse(fc["ReceiptDate"]);
            receipt.ReceiptAmount = Double.Parse(fc["ReceiptAmount"]);
            receipt.Receiptname = System.Text.Encoding.ASCII.GetBinary(fc["Receiptname"]);
            //Employee employee = new Employee();
            //employee.EmployeeId = Convert.ToInt32(TempData["EmpId"]);
            //employee.Name = fc["Name"];
            //employee.DateOfJoining = DateTime.Parse(fc["DateOfJoining"]);
            //employee.Location = fc["Location"];
            //employee.Department = fc["Department"];
            //employee.Experience = Convert.ToInt32(fc["Experience"]);
            //employee.Role = fc["Role"];
            //db.Entry(employee).State = EntityState.Modified;
            //db.SaveChanges();

            //return RedirectToAction("EmployeeDetails", new { id = employee.EmployeeId })
            return View();
        }
    }
}